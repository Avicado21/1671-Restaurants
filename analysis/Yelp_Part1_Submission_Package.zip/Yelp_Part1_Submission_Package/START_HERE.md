# Yelp Deliverable 2 Part 1

Prepared for Poojan Patel from the project files supplied on October 29, 2026.

## What is finished

The Part 1 write-up and all four dataset graphs are complete. The Word document is editable; the PDF is ready
to read or combine with the other report sections. These outputs use the actual uploaded pipeline reports.
No model-training results or synthetic examples are included.

The earlier Yelp_Feature_Comparison.ipynb is a separate Part 2 experiment. It is not needed for this Part 1 package.

Final dataset: 293,819 review rows, 9 CSV columns, 18 cuisine labels.
Training: 235,306. Development: 29,283. Test: 29,230.

## What is inside

| Folder | Contents | Use |
| --- | --- | --- |
| 01_Report | Word and PDF versions of Part 1 | Add this section to the group report. |
| 02_Figures_and_Tables | Four PNG graphs, exact CSV count tables, analysis summary | Graphs are ready to use. The comparison graph is already in the report. |
| 03_Code | Plotting script, Part 1 notebook, package requirements | Reproduce the figures if needed. |
| 04_Source_Reports | Dataset distribution, label map, feature statistics, original pipeline | Evidence and reproducibility. |

## 1 Download and open the files on Windows

1. Download Yelp_Part1_Submission_Package.zip.
2. Open your Downloads folder in File Explorer.
3. Right-click the ZIP and choose Extract All, then Extract.
4. Open the extracted Yelp_Part1_Submission_Package folder.
5. Open 01_Report/Yelp_Deliverable_2_Data_Analysis.pdf and review all pages.
6. Open 01_Report/Yelp_Deliverable_2_Data_Analysis.docx when copying this section into the group's editable report.

The PDF is your completed Part 1 section. Your group must combine it with Parts 2-4 for the full deliverable.

## 2 Put your work on Pitt OnDemand

This makes the work available in the shared project folder; it is separate from submitting on Canvas.

1. Connect to Pitt's network or GlobalProtect VPN as required and open https://ondemand.htc.crc.pitt.edu.
2. Sign in with your Pitt account.
3. Open Files, then the project directory. Use Change directory to enter:
   /ix1/cs1671-2026f/yelp
4. Use the folder-creation option to create part1_prp120. If it already exists, open it.
5. Open part1_prp120 and choose Upload.
6. Upload Yelp_Part1_Submission_Package.zip from your computer.
7. Choose Upload again. In the extracted 01_Report folder, select the PDF and DOCX and upload both.
8. Wait until the uploads finish. Confirm the ZIP, PDF, and DOCX appear in the file list.
9. Give the person assembling the group report this location:
   /ix1/cs1671-2026f/yelp/part1_prp120

If the shared folder is not writable, upload to a new part1_prp120 folder in your own OnDemand home directory
and give the files directly to the teammate assembling the report using your group's usual sharing method.
Do not change project-wide permissions to work around a permission error.

Uploading the ZIP is enough to keep all code, graphs, and supporting tables together. The separate PDF and DOCX
let your teammate open the report without extracting the archive. Extracting or running the ZIP on Pitt is optional.

## 3 Optional reproduction of the graphs on Pitt

The graphs are already generated, so this is not an additional requirement for finishing your section.

1. Open Interactive Apps -> Jupyter on OnDemand.
2. Request a Python 3 environment with NumPy and Matplotlib; start with 1 CPU, 4 GB memory, and 30 minutes.
3. Click Launch and wait for the session to show Running, then click Connect to Jupyter.
4. Upload 03_Code/Yelp_Part1_Data_Graphs.ipynb into the Jupyter file browser and open it.
5. Choose the Python 3 kernel. The project path is already entered.
6. Choose Run -> Run All Cells.
7. The notebook reads datasets/dataset_distribution.txt and features/capped/feature_stats.txt from the project.
8. It creates part1_outputs next to the notebook and displays the four figures.
9. Download the generated ZIP using the link in the last cell.
10. Save the notebook if you want to retain its visible outputs, then end the session using Delete under My Interactive Sessions.

If you prefer a script, upload 03_Code/plot_part1_data.py and run this in a terminal inside your Jupyter session,
from the directory that contains the script:

    python3 plot_part1_data.py --project-dir /ix1/cs1671-2026f/yelp --output-dir part1_outputs

To reproduce from the bundled report snapshots, run from 03_Code:

    python3 plot_part1_data.py --source-dir ../04_Source_Reports --output-dir part1_outputs

If the live project reports have changed, the regenerated counts may differ from this prepared report; use one
consistent dataset version throughout the group's report. The script checks that dataset and feature-report row counts agree.

## 4 Add Part 1 to the group report

1. Give the teammate compiling the report the DOCX and the full package ZIP.
2. Insert the Part 1 content, tables, and figure into the group's main document before Part 2.
3. Match headings and fonts to the group document if needed. Deliverable 2 has no required format beyond PDF.
4. Make sure the final group document contains Parts 1, 2, 3, and 4.
5. Export the assembled document as one PDF, such as Yelp_Deliverable_2.pdf.
6. Reopen the exported PDF and check that all sections, table columns, and figure labels are visible.
7. Include the group's baseline-result code or a GitHub repository link with a README, as required for Part 2.
   This package supplies the Part 1 plotting code only; it does not replace a teammate's baseline-result code.

For Word, use File -> Save As or Export and choose PDF. For a shared online editor, use its Download/Export as PDF option.

## 5 Submit through Canvas

The project page says to assemble the parts into a PDF and submit on Canvas. Follow the course assignment's group settings.

1. The group's designated submitter opens Canvas, the course, and the Deliverable 2 assignment.
2. Check the exact deadline, allowed file types, and submission instructions shown there. The project page lists October 29;
   the exact time is determined by Canvas.
3. Click Start Assignment or the available submission button.
4. Select File Upload and choose the complete group PDF.
5. Supply the baseline code files/README or repository link as the assignment allows. If uploading a code ZIP,
   include the group's full required code, not just this Part 1 package.
6. Wait for the file upload to finish, then click Submit Assignment.
7. Confirm the submission status/time and download or preview the submitted PDF to check it is the correct complete file.

Do not use the Part 1-only PDF as the entire group deliverable unless the instructor specifically requests separate sections.
Keep the Part 1 ZIP as your handoff/reproducibility package; it does not replace the required PDF submission.

## 6 Complete your own peer review

The Deliverable 2 page links a separate peer-review form. Complete it yourself using your group's actual contributions:
https://forms.cloud.microsoft/r/5i6LfDXViC

## Sources for the submission steps

- Assignment: https://michaelmilleryoder.github.io/cs1671_fall2026/project.html#deliverable-2
- Pitt file management: https://crc-pages.pitt.edu/user-manual/getting-started/open-ondemand/
- Pitt interactive apps: https://crc-pages.pitt.edu/user-manual/web-portals/open-ondemand-apps/
- Canvas file submission: https://community.instructure.com/en/kb/articles/661210-how-do-i-submit-an-online-assignment

The prepared report was checked against the uploaded summary reports and pipeline code. It does not claim a new scan
of the large raw CSV or a live login to Pitt or Canvas. Account uploads, final group assembly, submission, and peer review
remain actions for you and your group.
